# haotbquan

#### 项目介绍
淘宝券网址导航, Flask+Bootstrap开发的网址导航

使用python3+

#### 软件架构
软件架构说明


#### 安装教程

git clone https://github.com/lqkweb/sqlflow.git

pip install -r requirements.txt

#### 使用说明

1. python manage.py


#### 更多

更多原创站点：
百度云搜索 http://www.lqkweb.com  http://www.81ad.cn
淘宝券搜索 http://www.tbquan.cn   http://www.wodecai.cn
网盘搜索   http://www.kaclub.cn   http://pan.tbquan.cn